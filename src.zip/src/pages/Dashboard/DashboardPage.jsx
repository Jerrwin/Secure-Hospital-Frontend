import React from "react";
import { Result, Button, Spin, Tag, Space } from "antd";

import UnifiedDashboard from "../../components/layout/DashboardLayout/UnifiedDashboard";
import useDashboard from "../../components/layout/DashboardLayout/useDashboard";
import useAuth from "../../modules/auth/hooks/useAuth";
import ErrorBoundary from "../../components/common/ErrorBoundary";
import { useTheme } from "../../context/ThemeContext";
import styled from "styled-components";

import LoadingScreen from "../../components/common/LoadingScreen";
import usePatients from "../../modules/patients/hooks/usePatients";
import useAppointments from "../../modules/appointments/hooks/useAppointments";
import { useEffect } from "react";

const DashboardHeader = styled.div`
  margin-bottom: 24px;
`;

const WelcomeTitle = styled.h1`
  color: ${props => props.theme.secondary};
  font-size: 1.75rem;
  margin: 0;
`;

const SubtitleText = styled.p`
  color: ${props => props.theme.text.secondary};
  margin-top: 4px;
`;

const DashboardPage = () => {
  const { theme } = useTheme();
  const { user, userRole } = useAuth();
  const dashboardData = useDashboard(user);
  const { patients, fetchPatients } = usePatients();
  const { list: allAppointments, fetchAll: fetchAppointments } = useAppointments();

  useEffect(() => {
    fetchPatients();
    fetchAppointments();
  }, [fetchPatients, fetchAppointments]);

  // Guard: If user is not yet loaded, show loading
  if (!user) {
    return <LoadingScreen fullPage label="Loading Dashboard..." />;
  }

  // Error Handling State
  if (dashboardData.error) {
    return (
      <div style={{ padding: "40px" }}>
        <Result
          status="500"
          title="Data Synchronization Failed"
          subTitle="We couldn't load your dashboard data. Please check your connection."
          extra={
            <Button type="primary" onClick={() => window.location.reload()}>
              Reload Page
            </Button>
          }
        />
      </div>
    );
  }

  return (
    <>
      <DashboardHeader>
        <Space align="center" size="middle">
          <WelcomeTitle>Welcome back, {user?.name}</WelcomeTitle>
          <Tag
            color={theme.primary}
            style={{
              borderRadius: "12px",
              fontWeight: 600,
              textTransform: "uppercase",
            }}
          >
            {userRole}
          </Tag>
        </Space>
        <SubtitleText>
          Here is what's happening in your workspace today.
        </SubtitleText>
      </DashboardHeader>

      {dashboardData.loading && !dashboardData.stats ? (
        <div style={{ textAlign: "center", padding: "100px 0" }}>
          <Spin size="large" />
        </div>
      ) : (
        <UnifiedDashboard
          role={userRole}
          data={dashboardData}
          patients={patients}
          allAppointments={allAppointments}
          loading={dashboardData.loading}
        />
      )}
    </>
  );
};

export default DashboardPage;
