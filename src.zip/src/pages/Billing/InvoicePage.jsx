import React, { useState } from "react";
import styled from "styled-components";
import { useTheme } from "../../context/ThemeContext";
import { Tabs } from "antd";
import { 
  FileTextOutlined, 
  HourglassOutlined, 
  CheckCircleOutlined,
  MoneyCollectOutlined 
} from "@ant-design/icons";
import CreateInvoiceTab from "./tabs/CreateInvoiceTab";
import PendingPaymentsTab from "./tabs/PendingPaymentsTab";
import CompletedPaymentsTab from "./tabs/CompletedPaymentsTab";

// ─── Breakpoints (Dynamic Helpers) ───────────────────────────────────────────
const bp = {
  xs: (props) => props.theme.breakpoints.xs,
  sm: (props) => props.theme.breakpoints.sm,
  md: (props) => props.theme.breakpoints.md,
  lg: (props) => props.theme.breakpoints.lg,
  xl: (props) => props.theme.breakpoints.xl,
};


const Container = styled.div`
  padding: 0;
  background: ${props => props.theme.background.main};
  min-height: calc(100vh - 64px);
`;

const HeaderCard = styled.div`
  background: ${props => props.theme.background.card};
  border: 1px solid ${props => props.theme.border};
  border-radius: 12px;
  box-shadow: ${props => props.theme.shadow};
  margin-bottom: 24px;
  overflow: hidden;
`;

const HeaderRow = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
  padding: 12px 16px;

  @media (min-width: ${props => props.theme.breakpoints.lg}) {
    padding: 16px 22px;
  }
`;

const HeaderLeft = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  flex: 1;
  min-width: 0;
`;

const TitleIcon = styled.div`
  width: 34px;
  height: 34px;
  border-radius: 9px;
  background: ${props => props.theme.primaryLight};
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  @media (min-width: ${bp.md}) {
    width: 40px;
    height: 40px;
    border-radius: 10px;
  }
`;

const PageTitle = styled.h2`
  font-size: 15px;
  font-weight: 700;
  color: ${props => props.theme.text.primary};
  margin: 0;
  letter-spacing: -0.2px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  @media (min-width: ${bp.sm}) {
    font-size: 17px;
  }
  @media (min-width: ${bp.md}) {
    font-size: 18px;
  }
`;

const StyledTabs = styled(Tabs)`
  .ant-tabs-nav {
    margin-bottom: 32px !important;
    &::before {
      display: none;
    }
  }

  .ant-tabs-tab {
    background: ${props => props.theme.background.card} !important;
    border: 1px solid ${props => props.theme.border} !important;
    border-radius: 8px !important;
    padding: 8px 16px !important;
    transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
    margin: 0 8px 0 0 !important;

    &:hover {
      border-color: ${props => props.theme.primary} !important;
      color: ${props => props.theme.primary} !important;
    }

    .ant-tabs-tab-btn {
      color: ${props => props.theme.text.secondary} !important;
      font-weight: 500 !important;
    }
  }

  .ant-tabs-tab-active {
    background: ${props => props.theme.primary} !important;
    border-color: ${props => props.theme.primary} !important;

    .ant-tabs-tab-btn {
      color: #ffffff !important;
    }
  }

  .ant-tabs-ink-bar {
    display: none !important;
  }

  .ant-tabs-content-holder {
    background: ${props => props.theme.background.card};
    padding: clamp(12px, 4vw, 24px);
    border-radius: 12px;
    box-shadow: ${props => props.theme.shadow};
  }

  @media (max-width: 576px) {
    .ant-tabs-nav {
      margin-bottom: 12px !important;
    }
    .ant-tabs-tab {
      padding: 4px 8px !important;
      margin-right: 4px !important;
      .ant-tabs-tab-btn {
        font-size: 11px;
      }
      .anticon {
        display: none;
      }
    }
  }
`;

const InvoicePage = () => {
  const { theme } = useTheme();
  const [activeKey, setActiveKey] = useState("create");

  const tabItems = [
    {
      key: "create",
      label: (
        <span>
          <FileTextOutlined /> Payment Create
        </span>
      ),
      children: <CreateInvoiceTab setActiveKey={setActiveKey} />,
    },
    {
      key: "pending",
      label: (
        <span>
          <HourglassOutlined /> Pending Payments
        </span>
      ),
      children: <PendingPaymentsTab setActiveKey={setActiveKey} />,
    },
    {
      key: "completed",
      label: (
        <span>
          <CheckCircleOutlined /> Completed Payments
        </span>
      ),
      children: <CompletedPaymentsTab />,
    },
  ];

  return (
    <Container>
      <HeaderCard>
        <HeaderRow>
          <HeaderLeft>
            <TitleIcon>
              <MoneyCollectOutlined style={{ fontSize: 22, color: theme.primary }} />
            </TitleIcon>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              <PageTitle>Billing & Payments</PageTitle>
            </div>
          </HeaderLeft>
        </HeaderRow>
      </HeaderCard>

      <div style={{ padding: '0 4px' }}>
        <StyledTabs 
          activeKey={activeKey} 
          onChange={setActiveKey}
          items={tabItems} 
        />
      </div>
    </Container>
  );
};

export default InvoicePage;
